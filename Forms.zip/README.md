# miniMarketWinForms
para tener un repositorio comun del proyecto de vs c# con winForms  
