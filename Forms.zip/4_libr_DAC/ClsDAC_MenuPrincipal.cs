﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAC
{
    public class ClsDAC_MenuPrincipal
    {
        public List<string> findOptionsByIdUsrRol(int usrIdLogued)
        {

            return null;
        }
    }
}
