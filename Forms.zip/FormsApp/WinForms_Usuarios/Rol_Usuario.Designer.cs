﻿namespace FormsApp.WinForms_Usuarios
{
    partial class Rol_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Forms_rol = new System.Windows.Forms.Button();
            this.creacion_rol = new System.Windows.Forms.Button();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.button14 = new System.Windows.Forms.Button();
            this.Rol_user = new System.Windows.Forms.Button();
            this.creacion_Rol1 = new FormsApp.WinForms_Usuarios.Creacion_Rol();
            this.asignacion_Rol1 = new FormsApp.WinForms_Usuarios.Asignacion_Rol();
            this.forms_Rol1 = new FormsApp.WinForms_Usuarios.Forms_Rol();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.Forms_rol);
            this.panel1.Controls.Add(this.creacion_rol);
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.Rol_user);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(177, 543);
            this.panel1.TabIndex = 1;
            // 
            // Forms_rol
            // 
            this.Forms_rol.FlatAppearance.BorderSize = 0;
            this.Forms_rol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Forms_rol.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Forms_rol.ForeColor = System.Drawing.Color.White;
            this.Forms_rol.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Forms_rol.Location = new System.Drawing.Point(12, 162);
            this.Forms_rol.Name = "Forms_rol";
            this.Forms_rol.Size = new System.Drawing.Size(165, 54);
            this.Forms_rol.TabIndex = 5;
            this.Forms_rol.Text = "Forms_rol";
            this.Forms_rol.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Forms_rol.UseVisualStyleBackColor = true;
            this.Forms_rol.Click += new System.EventHandler(this.Forms_rol_Click);
            // 
            // creacion_rol
            // 
            this.creacion_rol.FlatAppearance.BorderSize = 0;
            this.creacion_rol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.creacion_rol.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creacion_rol.ForeColor = System.Drawing.Color.White;
            this.creacion_rol.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.creacion_rol.Location = new System.Drawing.Point(12, 59);
            this.creacion_rol.Name = "creacion_rol";
            this.creacion_rol.Size = new System.Drawing.Size(165, 54);
            this.creacion_rol.TabIndex = 4;
            this.creacion_rol.Text = "creacion rol";
            this.creacion_rol.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.creacion_rol.UseVisualStyleBackColor = true;
            this.creacion_rol.Click += new System.EventHandler(this.creacion_rol_Click);
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.SidePanel.Location = new System.Drawing.Point(1, 61);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 54);
            this.SidePanel.TabIndex = 4;
            // 
            // button14
            // 
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button14.Location = new System.Drawing.Point(3, 546);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(36, 34);
            this.button14.TabIndex = 4;
            this.button14.Text = "?";
            this.button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // Rol_user
            // 
            this.Rol_user.FlatAppearance.BorderSize = 0;
            this.Rol_user.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Rol_user.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rol_user.ForeColor = System.Drawing.Color.White;
            this.Rol_user.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Rol_user.Location = new System.Drawing.Point(12, 113);
            this.Rol_user.Name = "Rol_user";
            this.Rol_user.Size = new System.Drawing.Size(165, 54);
            this.Rol_user.TabIndex = 4;
            this.Rol_user.Text = "rol_user";
            this.Rol_user.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Rol_user.UseVisualStyleBackColor = true;
            this.Rol_user.Click += new System.EventHandler(this.Rol_user_Click);
            // 
            // creacion_Rol1
            // 
            this.creacion_Rol1.Location = new System.Drawing.Point(183, 12);
            this.creacion_Rol1.Name = "creacion_Rol1";
            this.creacion_Rol1.Size = new System.Drawing.Size(384, 547);
            this.creacion_Rol1.TabIndex = 4;
            // 
            // asignacion_Rol1
            // 
            this.asignacion_Rol1.Location = new System.Drawing.Point(203, -11);
            this.asignacion_Rol1.Name = "asignacion_Rol1";
            this.asignacion_Rol1.Size = new System.Drawing.Size(348, 517);
            this.asignacion_Rol1.TabIndex = 3;
            // 
            // forms_Rol1
            // 
            this.forms_Rol1.Location = new System.Drawing.Point(183, 12);
            this.forms_Rol1.Name = "forms_Rol1";
            this.forms_Rol1.Size = new System.Drawing.Size(344, 466);
            this.forms_Rol1.TabIndex = 2;
            // 
            // Rol_Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 543);
            this.Controls.Add(this.creacion_Rol1);
            this.Controls.Add(this.asignacion_Rol1);
            this.Controls.Add(this.forms_Rol1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Rol_Usuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rol_User";
            this.Load += new System.EventHandler(this.Rol_Usuario_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button creacion_rol;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button Rol_user;
        private Forms_Rol forms_Rol1;
        private System.Windows.Forms.Button Forms_rol;
        private Asignacion_Rol asignacion_Rol1;
        private Creacion_Rol creacion_Rol1;
    }
}